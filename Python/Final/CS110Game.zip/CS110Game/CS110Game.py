# --------------------------
# Adam Clements
# Make a Game-
#   -GOOGLE DINO GAME
#   -make a sprite class
#   -import the dinosaur and cacti and bird as images
#   -make a scrolling map
#   -make the dinosaur jump on space
#   -make a lose screen if a cactus is hit
#   -add a score mechanic
#   -make you win at 1000 score
# -------------------------------
# import necessary imports
import pygame, sys, random
from pygame.locals import *
#initialize pygame for the text later on
pygame.init()
#class for the 2 backgrounds
class Background(pygame.sprite.Sprite):
    #initialize the 2 backgrounds
    def __init__(self, image_file, location):
        pygame.sprite.Sprite.__init__(self)  # call Sprite initializer
        self.image = pygame.image.load(image_file)
        self.rect = self.image.get_rect()
        self.rect.left, self.rect.top = location

#make sprite method
class mySprite(pygame.sprite.Sprite):
    #initialize the sprite method, overloaded with image, x, y, gravity, and size
    #also add variables score and canJump
    def __init__(self, imgFile, xStartIn, yStartIn, gravIn, size):
        super().__init__()
        self.score = 0
        self.canJump = True
        #create a sprite for the overloaded information
        self.image = pygame.transform.scale(imgFile, (size, size))
        self.rect = self.image.get_rect(center=(xStartIn, yStartIn))
        self.xStart, self.yStart, self.grav = xStartIn, yStartIn, gravIn

    #add a function to make gravity work
    def jump(self, pressed):
        #get the y value of the dino
        y = dino.rect.top
        #check what the y value is, and reverse/stop gravity accordingly
        if y >= 310:
            dino.rect.top = 310
            self.grav = 0
            self.canJump = True
            #use canJump to prevent flying
        if pressed[pygame.K_SPACE] and self.canJump:
            self.grav = -15
            self.canJump = False
        if y <= 170:
            self.grav = 15
        y += self.grav
        dino.rect.top = y

    #add a scroll function for the cacti, which get faster and faster as you go longer
    def scroll(self):
        if dino.score <= 100:
            a = 10
        elif dino.score <= 200:
            a = 12
        elif dino.score <= 300:
            a = 15
        elif dino.score <= 400:
            a = 17
        elif dino.score <= 500:
            a = 20
        elif dino.score <= 600:
            a = 22
        else:
            a = 25
        self.rect.left -= a

#function to make the screen scroll
def scrollBG():
    #begin with a white BG
    window.fill([255, 255, 255])
    #create 2 background image rectangles directly next to each other (one off screen)
    window.blit(BackGround1.image, BackGround1.rect)
    window.blit(BackGround2.image, BackGround2.rect)
    #make them both move in sync, to imitate a scrolling background
    BackGround1.rect.left -= 10
    BackGround2.rect.left -= 10
    #if the background goes off the left of the screen, move it back to off the right side to continue the cycle
    if BackGround1.rect.left == -800:
        BackGround1.rect.left = 800
    if BackGround2.rect.left == -800:
        BackGround2.rect.left = 800

#function to check if you run into a cactus
def checkCollision():
    if dino.rect.colliderect(cactus.rect):
        return True

#function to check if you won
def checkWin():
    if dino.score >= 1000:
        return True

#make dimensions of the screen
hSize = 800
vSize = 400
#create the window with said dimensions
window = pygame.display.set_mode((hSize, vSize), 0, 32)
# Set a caption for the display window
pygame.display.set_caption('Dinosaur Game')

# set up the colors (only needed for the text and white background)
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)


# Define gravity
grav = 5


# add images
DinoIMG = pygame.image.load('Dino2.png').convert_alpha()
CactusIMG = pygame.image.load("Cactus.png").convert_alpha()
# Create sprites
dino = mySprite(DinoIMG, 150, 330, grav, 70)
cactus = mySprite(CactusIMG, 900, 330, 0, 60)

# Get rid of the rectangle and replace with a sprite
all_sprites_list = pygame.sprite.Group()
all_sprites_list.add(dino)
all_sprites_list.add(cactus)

# Used to manage how fast the screen updates
clock = pygame.time.Clock()

#make fonts to use later
font1 = pygame.font.Font('GenghisKhan.otf',32)
font2 = pygame.font.Font('GenghisKhan.otf',20)

# Sets the auto-repeat for keys
pygame.key.set_repeat(50, 5)
BackGround1 = Background('BG1.png', [0, 0])
BackGround2 = Background('BG2.png', [800, 0])

while True:
    #run the game at 30 fps
    clock.tick(30)
    #if the player hasnt won or lost yet, play normally
    if not checkCollision() and not checkWin():
        for event in pygame.event.get():
            # If the event is quit, exit.
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
        #check if a key has been pressed
        pressed = pygame.key.get_pressed()

        #spawn a cactus if the previous one has left the screen, and the random number lands on 1
        x = random.randint(1, 15)
        if x == 1 and cactus.rect.left < 0:
            all_sprites_list.remove(cactus)
            cactus = mySprite(CactusIMG, 900, 330, 0, 60)
            all_sprites_list.add(cactus)
        #make the cactus scroll
        cactus.scroll()
        #increment the score
        dino.score += 1
        #set the score text
        text1 = font2.render("Score: " + str(dino.score),True,BLACK,WHITE)
        text1Rect = text1.get_rect()
        text1Rect.center = (700,50)
        #run the gravity function
        dino.jump(pressed)
        cactus.scroll()
        #scroll the background
        scrollBG()
        #draw the sprites
        all_sprites_list.draw(window)
        #print the score text
        window.blit(text1,text1Rect)
        #update the score
        pygame.display.update()
    #if the player hits a cactus, run the game over sequence
    elif checkCollision():
        for event in pygame.event.get():
            # If the event is quit, exit.
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
        window.fill(WHITE)
        text = font1.render("Game Over! Score: " + str(dino.score),True,BLACK,WHITE)
        textRect = text.get_rect()
        textRect.center = (400,200)
        window.blit(text,textRect)
        pygame.display.update()
    #if the player hits 1000 score, run the win sequence
    elif checkWin():
        for event in pygame.event.get():
            # If the event is quit, exit.
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
        window.fill(WHITE)
        text2 = font1.render("You Win!\nThe dinosaur has escaped the infinite desert!",True,BLACK,WHITE)
        text2Rect = text2.get_rect()
        text2Rect.center = (400,200)
        window.blit(text2,text2Rect)
        pygame.display.update()
